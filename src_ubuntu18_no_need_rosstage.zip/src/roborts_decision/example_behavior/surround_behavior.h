#ifndef ROBORTS_DECISION_SURROUND_BEHAVIOR_H
#define ROBORTS_DECISION_SURROUND_BEHAVIOR_H

#include "io/io.h"

#include "../blackboard/blackboard_new.h"
#include "../executor/chassis_executor.h"
#include "../executor/gimbal_executor.h"
#include "../behavior_tree/behavior_state.h"

namespace roborts_decision {
class SurroundBehavior {
 public:
  SurroundBehavior(ChassisExecutor* &chassis_executor, GimbalExecutor* &gimbal_executor,
               Blackboard* &blackboard) :
      chassis_executor_(chassis_executor), gimbal_executor_(gimbal_executor),
      blackboard_(blackboard), have_surround_goal_(false) { }

void Run(){
    blackboard_->partner_msg_pub_.status = (char)PartnerStatus::BATTLE;
    blackboard_->SuggestGimbalPatrol();
    blackboard_->PublishPartnerInformation();
    blackboard_->CheckCommunication();
    geometry_msgs::PoseStamped enemy_pose, self_pose;
    enemy_pose = blackboard_->GetCornerEnemyPose();
    auto yaw = enemy_pose.pose.orientation;
    self_pose = blackboard_->GetRobotMapPose();

    if (have_surround_goal_)
      have_surround_goal_ = blackboard_->cachedmapforchaseandsupport_ptr_->IsGoalStillAvailable(enemy_pose, goal_pose_);
    if (!have_surround_goal_)
      have_surround_goal_ = blackboard_->cachedmapforchaseandsupport_ptr_->FindSurroundGoal();

    if (have_surround_goal_)
      chassis_executor_->Execute(goal_pose_);
    else 
      chassis_executor_->Execute(enemy_pose);
  
}

void Cancel() {
	
    chassis_executor_->Cancel();
  }

BehaviorState Update() {
    return chassis_executor_->Update();
   
}

~SurroundBehavior() = default;

 public:
  bool have_surround_goal_;
  geometry_msgs::PoseStamped goal_pose_;
 private:
  //! executor
  ChassisExecutor* const chassis_executor_;
  GimbalExecutor* const gimbal_executor_;

  //! perception information
  Blackboard* const blackboard_;

  //geometry_msgs::PoseStamped planning_goal_;
};

}
#endif //ROBORTS_DECISION_SURROUND_BEHAVIOR_H
