#include <ros/ros.h>

#include "executor/chassis_executor.h"
#include "executor/gimbal_executor.h"

#include "example_behavior/back_boot_area_behavior.h"
#include "example_behavior/escape_behavior.h"
#include "example_behavior/chase_behavior.h"
#include "example_behavior/buff_chase_behavior.h"

#include "example_behavior/search_behavior.h"
#include "example_behavior/patrol_behavior.h"
#include "example_behavior/goal_behavior.h"
#include "example_behavior/round_behavior.h"
#include "example_behavior/support_behavior.h"
#include "example_behavior/surround_behavior.h"

#include "behavior_tree/behavior_tree.h"
#include "behavior_tree/behavior_node.h"
#include "blackboard/blackboard_new.h"
#include "behavior_tree/action_node.h"
/****************************************/
#include "example_behavior/turntohurt_behavior.h"
#include "example_behavior/buff_behavior.h"
/********************************************/
#include "example_behavior/getoutfromstuck_behavior.h"

int main(int argc, char **argv) {
  ros::init(argc, argv, "behavior_tree_new_node");
  std::string current_namespace = ros::this_node::getNamespace();
  if (current_namespace[0] == '/') current_namespace = current_namespace.substr(1);
  std::string full_path = ros::package::getPath("roborts_decision") + "/config/decision" + current_namespace + ".prototxt";

  auto chassis_executor = new roborts_decision::ChassisExecutor;
  auto gimbal_executor = new roborts_decision::GimbalExecutor;
  auto shoot_executor = new roborts_decision::ShootExecutor;
  auto blackboard = new roborts_decision::Blackboard(full_path);
	
  std::shared_ptr<roborts_decision::Blackboard> blackboard_ptr_(blackboard);

 // behavior
  roborts_decision::PatrolBehavior        patrol_behavior_(chassis_executor, blackboard, full_path);
  roborts_decision::SupportBehavior       support_behavior_(chassis_executor, gimbal_executor, blackboard);
  roborts_decision::ShootBehavior         shoot_behavior_(shoot_executor, chassis_executor, blackboard, full_path);
  roborts_decision::SupplyGoalBehavior    supply_goal_behavior_(chassis_executor, blackboard);
  roborts_decision::SupplyGoalOutBehavior supply_goalout_behavior_(chassis_executor, blackboard);
  roborts_decision::GuardGoalBehavior     guard_goal_behavior_(chassis_executor, blackboard);
  roborts_decision::SupplyBehavior        supply_application_behavior_(blackboard);
  roborts_decision::GainBuffGoalBehavior  gain_buff_goal_behavior_(chassis_executor, blackboard);
  roborts_decision::RoundBehavior         guard_behavior_(chassis_executor, blackboard, 5);
  roborts_decision::AccurSupplyBehavior   accur_supply_behavior_(chassis_executor, blackboard);
  roborts_decision::SurroundBehavior      surround_behavior_(chassis_executor, gimbal_executor, blackboard);
/***************************************************************/
  roborts_decision::ChaseBehavior          chase_behavior_(chassis_executor, blackboard, full_path);
  roborts_decision::BuffChaseBehavior      buff_chase_behavior_(chassis_executor, blackboard);
  roborts_decision::EscapeBehavior         escape_behavior_(chassis_executor, blackboard, full_path);
  roborts_decision::SearchBehavior         search_behavior_(chassis_executor, gimbal_executor, blackboard, full_path);
  roborts_decision::GainBuffBehavior       gain_buff_behavior_(chassis_executor, blackboard, full_path);
  
  roborts_decision::BackBootAreaBehavior   back_boot_area_behavior_(chassis_executor, blackboard, full_path);
  roborts_decision::TurnToHurtBehavior     turn_to_hurt_behavior_(chassis_executor, blackboard);
  roborts_decision::TurnBackBehavior       turn_back_behavior_(chassis_executor, blackboard);

  roborts_decision::GetOutFromStuckBehavior get_out_from_stuck_behavior_(chassis_executor, blackboard); 
/***************************************************************/
 //action
  auto patrol_action_ = std::make_shared<roborts_decision::PatrolAction>(blackboard_ptr_, patrol_behavior_);
  auto support_action_ = std::make_shared<roborts_decision::SupportAction>(blackboard_ptr_, support_behavior_);
  auto shoot_action_ = std::make_shared<roborts_decision::ShootAction>(blackboard_ptr_, shoot_behavior_);
  auto supply_goal_action_ = std::make_shared<roborts_decision::SupplyGoalAction>(blackboard_ptr_, supply_goal_behavior_);
  auto guard_goal_action_ = std::make_shared<roborts_decision::GuardGoalAction>(blackboard_ptr_, guard_goal_behavior_);
  auto supply_goalout_action_ = std::make_shared<roborts_decision::SupplyGoalOutAction>(blackboard_ptr_, supply_goalout_behavior_);
  auto supply_application_action_ = std::make_shared<roborts_decision::SupplyApplicateNode>(blackboard_ptr_, supply_application_behavior_);
  auto surround_action_ = std::make_shared<roborts_decision::SurroundAction>(blackboard_ptr_, surround_behavior_);
  auto gain_buff_goal_action_ = std::make_shared<roborts_decision::GainBuffGoalAction>(blackboard_ptr_, gain_buff_goal_behavior_);
  auto gain_buff_action_ = std::make_shared<roborts_decision::GainBuffAction>(blackboard_ptr_, gain_buff_behavior_);
  auto guard_action_ = std::make_shared<roborts_decision::GuardAction>(blackboard_ptr_, guard_behavior_);

  /***************************************************************/

  auto chase_action_ = std::make_shared<roborts_decision::ChaseAction>(blackboard_ptr_, chase_behavior_);
  auto buff_chase_action_ = std::make_shared<roborts_decision::BuffChaseAction>(blackboard_ptr_, buff_chase_behavior_);
  auto escape_action_ = std::make_shared<roborts_decision::EscapeAction>(blackboard_ptr_, escape_behavior_);
  auto search_action_ = std::make_shared<roborts_decision::SearchAction>(blackboard_ptr_, search_behavior_);
  auto wait_action_ = std::make_shared<roborts_decision::BackBootAreaAction>(blackboard_ptr_, back_boot_area_behavior_);
  auto turn_to_hurt_action_ = std::make_shared<roborts_decision::TurnToHurtAction>(blackboard_ptr_, turn_to_hurt_behavior_);
  auto turn_back_action_ = std::make_shared<roborts_decision::TurnBackAction>(blackboard_ptr_, turn_back_behavior_);

  auto get_out_from_stuck_action_ = std::make_shared<roborts_decision::GetOutFromStuckAction>(blackboard_ptr_, get_out_from_stuck_behavior_);
  auto accur_supply_action_ = std::make_shared<roborts_decision::AccurSupplyAction>(blackboard_ptr_, accur_supply_behavior_);
  /***************************************************************/

  /****************************************************第一层 root***********************************************/
  std::shared_ptr<roborts_decision::SelectorNode> root_node(new roborts_decision::SelectorNode("root_selector", blackboard_ptr_));
  
  
  /****************************************************第二层 start stop***********************************************/ 
  std::shared_ptr<roborts_decision::PreconditionNode> game_stop_condition_(new roborts_decision::PreconditionNode("game_stop_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->GetGameStatus() != roborts_decision::GameStatus::PRE_MATCH 
                                                                                                && blackboard_ptr_->GetGameStatus() != roborts_decision::GameStatus::ROUND) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  std::shared_ptr<roborts_decision::SelectorNode> game_start_selector(new roborts_decision::SelectorNode("game_start_selector", blackboard_ptr_));                                                                                            
  root_node->AddChildren(game_stop_condition_);  
  root_node->AddChildren(game_start_selector);
  game_stop_condition_->SetChild(wait_action_); 


  /****************************************************第三层 脱离 没子弹 没血 进攻***********************************************/ 
  
  //get stuck
  std::shared_ptr<roborts_decision::PreconditionNode> stuck_in_obstacle_condition_(new roborts_decision::PreconditionNode("stuck_in_obstacle_condition", blackboard_ptr_,
                                                                                              [&]() {
																																																if (blackboard_ptr_->IsStuckedAndCanGetOut()) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															}, roborts_decision::AbortType::BOTH));

  // no bullet left
  std::shared_ptr<roborts_decision::PreconditionNode> no_bullet_left_condition_(new roborts_decision::PreconditionNode("no_bullet_left_condition",blackboard_ptr_,
																																															[&]() {
                                                                                                if (blackboard_ptr_->GetBulletNum() < 20 ) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															}, roborts_decision::AbortType::BOTH));
  // no HP left
  std::shared_ptr<roborts_decision::PreconditionNode> no_HP_left_condition_(new roborts_decision::PreconditionNode("buff_inferior_condition",blackboard_ptr_,
																																															[&]() {
                                                                                               if (blackboard_ptr_->lowHp()) { 
                                                                                                  return true;
                                                                                               } else{
                                                                                                  return false;
                                                                                                 } 
                                                                                              }, roborts_decision::AbortType::BOTH));
  // offensive selector
  std::shared_ptr<roborts_decision::SelectorNode> offensive_selector(new roborts_decision::SelectorNode("offensive_selector", blackboard_ptr_));  

  game_start_selector->AddChildren(stuck_in_obstacle_condition_);
  game_start_selector->AddChildren(no_bullet_left_condition_);
  game_start_selector->AddChildren(no_HP_left_condition_);
  game_start_selector->AddChildren(offensive_selector);
  
  stuck_in_obstacle_condition_->SetChild(get_out_from_stuck_action_);


   /****************************************************没子弹************************************************/
  std::shared_ptr<roborts_decision::SelectorNode> no_bullet_left_selector(new roborts_decision::SelectorNode("no_bullet_left_selector", blackboard_ptr_));          
  std::shared_ptr<roborts_decision::PreconditionNode> nobullet_gain_buff_condition_(new roborts_decision::PreconditionNode("nobullet_gain_buff_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->GetBulletNum() < 20 &&
                                                                                                    blackboard_ptr_->isBulletBuffAvailable()) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  std::shared_ptr<roborts_decision::SelectorNode> nobullet_guard_selector(new roborts_decision::SelectorNode("nobullet_guard_selector", blackboard_ptr_)); 

  no_bullet_left_condition_->SetChild(no_bullet_left_selector);
  no_bullet_left_selector->AddChildren(nobullet_gain_buff_condition_);
  no_bullet_left_selector->AddChildren(nobullet_guard_selector);

  nobullet_gain_buff_condition_ ->SetChild(gain_buff_action_);

  std::shared_ptr<roborts_decision::PreconditionNode> nobullet_escape_guard_goal_condition_(new roborts_decision::PreconditionNode("escape_guard_goal_condition",blackboard_ptr_,
																																															[&]() {ROS_INFO("sArrivedGuardGoal%d",blackboard_ptr_->IsArrivedGuardGoal());
																																																if (blackboard_ptr_->NotGetDamageIn3Sec() && !blackboard_ptr_->IsArrivedGuardGoal()){
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  nobullet_guard_selector->AddChildren(nobullet_escape_guard_goal_condition_);
  nobullet_guard_selector->AddChildren(guard_action_);
  nobullet_escape_guard_goal_condition_->SetChild(guard_goal_action_);

  
  
   /****************************************************没血************************************************/
  std::shared_ptr<roborts_decision::SelectorNode> no_HP_left_selector(new roborts_decision::SelectorNode("no_HP_left_selector", blackboard_ptr_));          
  std::shared_ptr<roborts_decision::PreconditionNode> noHP_gain_buff_condition_(new roborts_decision::PreconditionNode("noHP_gain_buff_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->lowHp() &&
                                                                                                    blackboard_ptr_->isHPBuffAvailable()) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  std::shared_ptr<roborts_decision::SelectorNode> noHP_guard_selector(new roborts_decision::SelectorNode("noHP_guard_selector", blackboard_ptr_)); 

  no_HP_left_condition_->SetChild(no_HP_left_selector);
  no_HP_left_selector->AddChildren(noHP_gain_buff_condition_);
  no_HP_left_selector->AddChildren(noHP_guard_selector);

  noHP_gain_buff_condition_ ->SetChild(gain_buff_action_);

  std::shared_ptr<roborts_decision::PreconditionNode> noHP_escape_guard_goal_condition_(new roborts_decision::PreconditionNode("escape_guard_goal_condition",blackboard_ptr_,
																																															[&]() {ROS_INFO("sArrivedGuardGoal%d",blackboard_ptr_->IsArrivedGuardGoal());
																																																if (blackboard_ptr_->NotGetDamageIn3Sec() && !blackboard_ptr_->IsArrivedGuardGoal()){
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  noHP_guard_selector->AddChildren(nobullet_escape_guard_goal_condition_);
  noHP_guard_selector->AddChildren(guard_action_);
  noHP_escape_guard_goal_condition_->SetChild(guard_goal_action_);

  
  /****************************************************进攻************************************************/

  std::shared_ptr<roborts_decision::PreconditionNode> offensive_dmp_condition_(new roborts_decision::PreconditionNode("offensive_dmp_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->HurtedPerSecond() > 200) {
                                                                                                  ROS_INFO("DMP: %f",blackboard_ptr_->dmp_);
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  std::shared_ptr<roborts_decision::PreconditionNode> offensive_detect_enemy_condition_(new roborts_decision::PreconditionNode("offensive_detect_enemy_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->EnemyDetected()
                                                                                                == roborts_decision::EnemyStatus::FRONT) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));
  std::shared_ptr<roborts_decision::PreconditionNode> offensive_support_condition_(new roborts_decision::PreconditionNode("offensive_support_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->IsPartnerDetectEnemy() && 
                                                                                                 blackboard_ptr_-> EnemyDetected()== roborts_decision::EnemyStatus::NONE) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::LOW_PRIORITY));
  std::shared_ptr<roborts_decision::PreconditionNode> offensive_under_attack_condition_(new roborts_decision::PreconditionNode("offensive_under_attack_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->GetDamageSource()
                                                                                                    != roborts_decision::DamageSource::NONE
                                                                                                    && blackboard_ptr_->GetDamageSource()
                                                                                                        != roborts_decision::DamageSource::FORWARD) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::LOW_PRIORITY));
  std::shared_ptr<roborts_decision::PreconditionNode> offensive_back_detect_condition_(new roborts_decision::PreconditionNode("offensive_detected_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->EnemyDetected()
                                                                                                == roborts_decision::EnemyStatus::BACK) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::LOW_PRIORITY));                                                                                              
  std::shared_ptr<roborts_decision::PreconditionNode> offensive_corner_camera_detect_condition_(new roborts_decision::PreconditionNode("offensive_corner_camera_detect_condition",blackboard_ptr_,
																																															[&]() {
																																																if (blackboard_ptr_->EnemyDetected()
                                                                                                == roborts_decision::EnemyStatus::NONE && blackboard_ptr_->EnemyDisappear()) {
																																																	return true;
																																																} else {
																																																	return false;
																																																}
																																															} , roborts_decision::AbortType::BOTH));                                                                                            
  offensive_selector->AddChildren(offensive_dmp_condition_);
  offensive_selector->AddChildren(offensive_detect_enemy_condition_);
  offensive_selector->AddChildren(offensive_support_condition_);
  offensive_selector->AddChildren(offensive_under_attack_condition_);
  offensive_selector->AddChildren(offensive_back_detect_condition_);
  offensive_selector->AddChildren(offensive_corner_camera_detect_condition_);
  offensive_selector->AddChildren(patrol_action_);

  offensive_dmp_condition_->SetChild(guard_action_);
  offensive_detect_enemy_condition_->SetChild(chase_action_);
  offensive_support_condition_->SetChild(support_action_);
  offensive_under_attack_condition_->SetChild(turn_to_hurt_action_);
  offensive_back_detect_condition_->SetChild(turn_back_action_);
  offensive_corner_camera_detect_condition_->SetChild(surround_action_);


  roborts_decision::BehaviorTree behaviortree(root_node, 20);
  ros::Time SendArmorDetectionCmd_time = ros::Time::now();

  while(1){
    behaviortree.Run();
    if (ros::Time::now() - SendArmorDetectionCmd_time > ros::Duration(1)){
      blackboard_ptr_->SendArmorDetectionCmd();
      SendArmorDetectionCmd_time = ros::Time::now();
    }
    blackboard_ptr_->IsMasterCondition();
  }
  
  ros::waitForShutdown();
  return 0;
}


